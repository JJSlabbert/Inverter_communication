from flask import Flask, render_template
from pymodbus.client import ModbusSerialClient as ModbusClient
import time
import serial


PORT='/dev/ttyUSB0'

def get_string(res, index, length):  
    string = ""
    for pos in range(0, length):
        string += str(
            chr(res.registers[index + pos] >> 8)
            + chr(res.registers[index + pos] & 0x000000FF)
        )
    return string



try:
    client = ModbusClient(method='rtu', port=PORT, baudrate=9600, timeout=1)
    client.connect()
    readh=client.read_holding_registers(0,104,1) #Start, Count, Device adress
    print(readh.registers[5])
except:
    print('Fail1')
    try:
        time.sleep(1)
        PORT='/dev/ttyUSB1'
        client = ModbusClient(method='rtu', port=PORT, baudrate=9600, timeout=1)
        client.connect()
        readh=client.read_holding_registers(0,104,1) #Start, Count, Device adress
        print(readh.registers[5])
    except:
        print('Fail2')
        try:
            time.sleep(1)
            PORT='/dev/ttyUSB2'
            client = ModbusClient(method='rtu', port=PORT, baudrate=9600, timeout=1)
            client.connect()
            readh=client.read_holding_registers(0,104,1) #Start, Count, Device adress
            print(readh.registers[5])
        except:
            print('Fail3')
            print('Could not read registers')

print('Modbus Connected: ',client.connected, 'PORT: ',PORT)

print('Inverter Serial Number: ',get_string(readh, 23, 5))
print('Inverter Firmware Version: ',get_string(readh, 9, 3))
print('Modbus Version: ',get_string(readh, 12, 3))

holding_reg_list=[]
print ('Reading the holding registers values. These are also writable')


for i in range(80):
    data=readh.registers[int(i)] #read register id 64
    holding_reg_list.append(data)
    
print(holding_reg_list)


input_reg_list=[]
print ('Reading input registers. You can not write to them')

readi=client.read_input_registers(0,127,1) #Start, End, Device adressprint ('Reading the holding registers values. These are also writable')
for i in range(127):
    data=readi.registers[int(i)] #read register id 64
    input_reg_list.append(data)
    #print(i, data) #print register data
print(input_reg_list)

app = Flask(__name__)

@app.route('/')
def index():
    data={'serial_num':get_string(readh, 23, 5), 'firmware_version':get_string(readh, 9, 3), 'modbus_version':get_string(readh, 12, 3)}
    return render_template('index.html',**data)
@app.route('/holding_registers')
def holding_registers():
    readh=client.read_holding_registers(0,105,1)
    return render_template('holding_registers.html',readh=readh)
 
@app.route('/input_registers')
def input_registers():
    readi=client.read_input_registers(0,127,1)
    return render_template('input_registers.html',readi=readi)
@app.route('/battery_readings')
def battery_readings():
    return render_template('battery_readings.html')

if __name__ == '__main__':
    try:
        app.run(debug=True, host='0.0.0.0')
    except:
        print('Could not start flask web server. It is maybe already started?')
