from flask import Flask, render_template, request
from pymodbus.client import ModbusSerialClient as ModbusClient
import time
import serial

#Battery BMS Things
from support_BMS.pylon_jsonencoder import encodePylon_readings, encodePylon_info
from support_BMS.pylon_validate import handleArgs
from support_BMS.pylontech import Pylontech
from support_BMS.pylontech import PylonTechSOK
from time import time_ns
pylonPort="/dev/ttyUSB0"
baud_rate="9600"

PORT='/dev/ttyUSB0' #This is the INVERTER MODBUS Port

def get_string(res, index, length):  
    string = ""
    for pos in range(0, length):
        string += str(
            chr(res.registers[index + pos] >> 8)
            + chr(res.registers[index + pos] & 0x000000FF)
        )
    return string



# Connecting to Inverter MODBUS PORT
print('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('Connecting to Inverter...')
try:
    client = ModbusClient(method='rtu', port=PORT, baudrate=9600, timeout=1)
    client.connect()
    readh=client.read_holding_registers(0,104,1) #Start, Count, Device adress    
except:
    print('Fail1')
    try:
        time.sleep(1)
        PORT='/dev/ttyUSB1'
        client = ModbusClient(method='rtu', port=PORT, baudrate=9600, timeout=1)
        client.connect()
        readh=client.read_holding_registers(0,104,1) #Start, Count, Device adress
    except:
        print('Fail2')
        try:
            time.sleep(1)
            PORT='/dev/ttyUSB2'
            client = ModbusClient(method='rtu', port=PORT, baudrate=9600, timeout=1)
            client.connect()
            readh=client.read_holding_registers(0,104,1) #Start, Count, Device adress
        except:
            print('Fail3')
            print('Could not read registers')

print('Modbus Connected: ',client.connected, 'PORT: ',PORT)

print('Inverter Serial Number: ',get_string(readh, 23, 5))
print('Inverter Firmware Version: ',get_string(readh, 9, 3))
print('Modbus Version: ',get_string(readh, 12, 3))

holding_reg_list=[]
print ('Reading the holding registers values. These are also writable')


for i in range(80):
    data=readh.registers[int(i)] #read register id 64
    holding_reg_list.append(data)
    
print(holding_reg_list)


input_reg_list=[]
print ('Reading input registers. You can not write to them')

readi=client.read_input_registers(0,127,1) #Start, End, Device adressprint ('Reading the holding registers values. These are also writable')
for i in range(127):
    data=readi.registers[int(i)] #read register id 64
    input_reg_list.append(data)
    #print(i, data) #print register data
print(input_reg_list)

print('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('Connecting to Battery...')
try:
    pylontech = PylonTech(pylonPort,baud_rate)
    print('Bar Code: ',pylontech.get_barcode(1))
    print('Firmware Version: ',pylontech.get_version_info(1))
except:
    try:
        pylonPort="/dev/ttyUSB1"
        pylontech = PylonTechSOK(pylonPort,baud_rate)
        print('Bar Code: ',pylontech.get_barcode(1))
        print('Firmware Version: ',pylontech.get_version_info(1))
    except:
        try:
            pylonPort="/dev/ttyUSB2"
            pylontech = PylonTechSOK(pylonPort,baud_rate)
            print('Bar Code: ',pylontech.get_barcode(1))
            print('Firmware Version: ',pylontech.get_version_info(1))
        except:
            print('Could not connect to battery on ttyUSB0, ttyUSB1, ttyUSB2')

print('++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('Starting flask web server...')

app = Flask(__name__)
print('App loop')

@app.route('/')
def index():
    data={'inv_serial_num':get_string(readh, 23, 5), 'inv_firmware_version':get_string(readh, 9, 3),
          'inv_modbus_version':get_string(readh, 12, 3),'bat_bar_code':pylontech.get_barcode(1),
          'bat_firmware_version':pylontech.get_version_info(1)}
    return render_template('index.html',**data)
@app.route('/holding_registers', methods=['GET', 'POST'])
def holding_registers():
    if request.method == 'POST':
        register_val=int(request.form.get('reg_val'))
        register_num=int(request.form.get('reg_num'))
        client.write_registers(register_num,register_val,1)
        time.sleep(3)
        readh=client.read_holding_registers(0,105,1)
        print(register_num, register_val)
        return render_template('holding_registers.html',readh=readh)
        
    readh=client.read_holding_registers(0,105,1)
    return render_template('holding_registers.html',readh=readh)
 
@app.route('/input_registers')
def input_registers():
    readi=client.read_input_registers(0,127,1)
    return render_template('input_registers.html',readi=readi)
@app.route('/battery_readings')
def battery_readings():
##    data={'bar_code':pylontech.get_barcode(1), 'firmware_version':pylontech.get_version_info(1), 'cell_voltages':pylontech.get_values_single(1).CellVoltages,
##          'temps':pylontech.get_values_single(1).GroupedCellsTemperatures,}
    return render_template('battery_readings.html',bms=pylontech.get_values_single(1))

if __name__ == '__main__':
    try:
        app.run(debug=False, host='0.0.0.0') #If debug is True, python can not get the POST results from the web
    except:
        print('Could not start flask web server. It is maybe already started?')
