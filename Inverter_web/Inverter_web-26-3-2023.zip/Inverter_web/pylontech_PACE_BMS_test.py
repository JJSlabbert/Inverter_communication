
from support_BMS.pylon_jsonencoder import encodePylon_readings, encodePylon_info
from support_BMS.pylon_validate import handleArgs
from support_BMS.pylontech import Pylontech
from support_BMS.pylontech import PylonTechSOK
from time import time_ns
pylonPort="/dev/ttyUSB0"
baud_rate="9600"
try:
    pylontech = PylonTech(pylonPort,baud_rate)
    print('Bar Code: ',pylontech.get_barcode(1))
    print('Firmware Version: ',pylontech.get_version_info(1))
except:
    try:
        pylonPort="/dev/ttyUSB1"
        pylontech = PylonTechSOK(pylonPort,baud_rate)
        print('Bar Code: ',pylontech.get_barcode(1))
        print('Firmware Version: ',pylontech.get_version_info(1))
    except:
        try:
            pylonPort="/dev/ttyUSB2"
            pylontech = PylonTechSOK(pylonPort,baud_rate)
            print('Bar Code: ',pylontech.get_barcode(1))
            print('Firmware Version: ',pylontech.get_version_info(1))
        except:
            print('Could not connect to battery on ttyUSB0, ttyUSB1, ttyUSB2')

print("Reading sensor values from the battery")

print(pylontech.get_values_single(1))
pylontech_values=pylontech.get_values_single(1)
print('Individual Cell voltages')
for i in range(pylontech_values.NumberOfCells):
    print(i, pylontech_values.CellVoltages[i])
print('Individual Temp values')    
for i in range(pylontech_values.NumberOfTemperatures):
    print(i, pylontech_values.GroupedCellsTemperatures[i])
